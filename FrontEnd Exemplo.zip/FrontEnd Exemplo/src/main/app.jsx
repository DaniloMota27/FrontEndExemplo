import React from 'react'

import '../static/js/dependencies'
import Header from '../componentes/auxiliares/header/header'
import SideBar from '../componentes/auxiliares/menu/sidebar'
import Footer from '../componentes/auxiliares/footer/footer'
import Msg from '../componentes/auxiliares/msg/msgs'


export default props => (
    <div className='wrapper'>
        <Header />
        <SideBar />
        
        <Footer />
    <Msg />
   
    </div>
)