import React from 'react'
import { Switch , Route, IndexRoute, Redirect } from 'react-router-dom'

import Dashboard from '../componentes/principal/dashboard/dashboard'
import ManagerUrls from '../componentes/principal/urls/managerurls'
import ManagerGmuds from '../componentes/principal/gmuds/managergmud'
import ManagerServidores from '../componentes/principal/servidores/managerservidores'
import ManagerDB from '../componentes/principal/urldb/urldb'
import ManagerSigla from '../componentes/principal/siglas/managersiglas'

export default () => (


            <Switch>
                <Route path="/" exact={true} component={Dashboard} />
                <Route path="/urlsmanager" component={ManagerUrls} />  
                <Route path="/gmudmanager" component={ManagerGmuds} />  
                <Route path="/servidoresmanager" component={ManagerServidores} />  
                <Route path="/siglasmanager" component={ManagerSigla} />  
                <Route path="/dbmanager" component={ManagerDB} />

                      
                <IndexRoute component={Dashboard} />
                <Redirect from='*' to='/' />    
            </Switch>



)