import React from 'react'


export default props => (
    <section className="content-header">
        <h2>{props.title} <small>{props.small}</small></h2>
    </section>
)