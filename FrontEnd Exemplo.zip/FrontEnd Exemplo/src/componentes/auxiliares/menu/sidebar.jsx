import React from 'react'
import Menu from './menu'
import {BrowserRouter} from 'react-router-dom'
import Routes from '../../../main/routes'
export default props => (
    <BrowserRouter>
    <aside className="main-sidebar">
        <section className="sidebar">
            <Menu />
        </section>
        </aside>
        <div className='content-wrapper'> 
            <Routes></Routes>
        </div>
    
    </BrowserRouter>
)