import React from "react";
import MenuItem from "./menuitem";
import MenuTree from "./menutree";

export default (props) => (
  <ul className="sidebar-menu">
    <MenuItem path="/" label="Dashboard" icon="dashboard"></MenuItem>
    <MenuTree label="URL " icon="podcast">
      <MenuItem
        path="/urlsmanager"
        label="Gerenciamento URLS"
        icon="internet-explorer"
      ></MenuItem>
    </MenuTree>
    <MenuTree label="GMUD " icon="handshake-o">
      <MenuItem
        path="/gmudmanager"
        label="Gerenciamento GMUD"
        icon="address-book-o"
      ></MenuItem>
    </MenuTree>
    <MenuTree label="Siglas " icon="briefcase">
      <MenuItem
        path="/siglasmanager"
        label="Gerenciamento Siglas"
        icon="users"
      ></MenuItem>
    </MenuTree>
    <MenuTree label="Servidores " icon="cogs">
      <MenuItem
        path="/servidoresmanager"
        label="Gerenciamento Servidores"
        icon="server"
      ></MenuItem>
    </MenuTree>
    <MenuTree label="Database " icon="database">
      <MenuItem
        path="/dbmanager"
        label="Gerenciamento Database"
        icon="table"
      ></MenuItem>
    </MenuTree>
  </ul>
);
