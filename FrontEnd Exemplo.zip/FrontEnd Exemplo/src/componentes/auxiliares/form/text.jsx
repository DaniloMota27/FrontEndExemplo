import React from 'react'

export default (props) => {
    return(
        <small  class="form-text text-muted">{props.text}</small>
    )
}