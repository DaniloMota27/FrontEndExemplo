import React, {useEffect, useState ,useRef} from 'react';
import {useDispatch} from 'react-redux'
import axios from 'axios'
import { Form } from '@unform/web'
import Input from './input'
import Label from './label'
import * as Yup from 'yup'
import Btn from './btn'
import { toastr } from 'react-redux-toastr'
import {innit} from '../../../redux/actions/managergmudActions'

export default function FormGMUD(props){
    const formRef = useRef(null);
    const metodo = props.method

    const initialData = props.dataForm  
    const dispatch = useDispatch();      
    const readOnly = props.readOnly
    async function submit(data, { reset }) {
        
        try {
            const schema = Yup.object().shape({
                numero: Yup.string().required('Informe o número da gmud'),
                complemento: Yup.string().required('Informe uma descrição'),
                start: Yup.string().required('Informe uma data válida'),
                end: Yup.string().required('Informe uma data válida')
            })
            await schema.validate(data, {
                abortEarly: false,
            })
            formRef.current.setErrors({})
            

            const baseUrl = 'http://127.0.0.1:8000/api/v2'
            const id = data.id ? data.id : ''
            const url = metodo == 'post' ? `${baseUrl}/gmuds/` : `${baseUrl}/gmuds/${id}/`
            await axios[metodo](`${url}`, data)
            .then(resp => {
                        const success = toastr.success('Sucesso', 'Operação realizada com sucesso')})
            .then( e => 
                    dispatch(innit())
                    
            )                    
            .catch(e => {
                        e.response.data.errors.forEach(error => toastr.error('Erro', error))
                        })
                        if (motodo = 'post'){
                            reset()
                    }
        }
        catch (err) {
            if (err instanceof Yup.ValidationError) {
                const errorMessages = {};
                err.inner.forEach(error => {
                    errorMessages[error.path] = error.message
                })
                formRef.current.setErrors(errorMessages)
            
            }
        }
          
        
        }

    return (      
        <Form ref={formRef} initialData={initialData} onSubmit={submit}>
               <div className="form-row">
                    <div className="form-group col-md-3">
                            <Input name='id'  type='hidden' />
                            <Label for="numerodagmud" label="Digite o número da GMUD" />
                            <Input name='numero' readOnly={readOnly} type='text' />
                    </div>
                    <div className="form-group col-md-3">
                            <Label for="complementogmud" label="Descrição:" />
                            <Input name='complemento' readOnly={readOnly} type='text' />
                    </div>
                    <div className="form-group col-md-3">
                            <Label for="datagmud" label="Inicio:" />
                            <Input name='start' readOnly={readOnly} type='date' />
                    </div>
                    <div className="form-group col-md-3">
                            <Label for="datagmud" label="Termino:" />
                            <Input name='end' readOnly={readOnly} type='date' />
                    </div>
                </div>

            <div className="form-group row">
                <div className="col-md-10">
                    <Btn metodo={metodo}/>
                </div>
            </div>           
        </Form>
    )
}


