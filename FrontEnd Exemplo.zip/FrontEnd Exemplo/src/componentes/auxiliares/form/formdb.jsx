import React, { useEffect, useState, useRef } from "react";
import { useDispatch } from "react-redux";
import axios from "axios";
import { Form } from "@unform/web";
import Input from "./input";
import Label from "./label";
import Select from "./select";

import * as Yup from "yup";
import Btn from "./btn";
import { toastr } from "react-redux-toastr";
import { innit } from "../../../redux/actions/urlsdbActions";

export default function FormDB(props) {
  const formRef = useRef(null);
  const metodo = props.method;
  const options = [
    { label: "Excluído", value: "Removido" },
    { label: "Não Excluído", value: "Online" },
    
  ];
  
  const initialData = props.dataForm;
  const dispatch = useDispatch();
  const readOnly = props.readOnly;
  
  async function submit(data, { reset }) {
  
    
    try {
      const schema = Yup.object().shape({
        nome: Yup.string().required("Informe o nome da sigla"),
        tamanho: Yup.string().required("Informe o tamanho do banco de dados"),
        excluido: Yup.string().required("Informe se o banco foi excluido"),
      });
      await schema.validate(data, {
        abortEarly: false,
      });
      formRef.current.setErrors({});
      
      
      const baseUrl = "http://127.0.0.1:8000/api/v2";
      const id = data.id ? data.id : "";
      const url =
        metodo == "post" ? `${baseUrl}/bancos/` : `${baseUrl}/bancos/${id}/`;
      await axios[metodo](`${url}`, data)
        .then((resp) => {
          const success = toastr.success(
            "Sucesso",
            "Operação realizada com sucesso"
          );
        })
        .then((e) => dispatch(innit()))
        .catch((e) => {
          e.response.data.errors.forEach((error) =>
            toastr.error("Erro", error)
          );
        });
      if ((motodo = "post")) {
        reset();
      }
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
        const errorMessages = {};
        err.inner.forEach((error) => {
          errorMessages[error.path] = error.message;
        });
        formRef.current.setErrors(errorMessages);
      }
    }
  }
  return (
    <Form ref={formRef} initialData={initialData} onSubmit={submit}>
      <div className="form-row">
        <div className="form-group col-md-4">
          <Input name="id" type="hidden" />
          <Label for="nomedobanco" label="Nome do Banco:" />
          <Input readOnly={readOnly} name="nome" type="text" />
        </div>
        <div className="form-group col-md-4">
          <Label for="tamanhobanco" label="Tamanho DB:" />
          <Input readOnly={readOnly} name="tamanho" type="number" />
        </div>
        <div className="form-group col-md-4">
          <Label for="excluido" label="Excluido:" />
          <Select readOnly={readOnly} name="excluido" options={options} />
        </div>
      </div>

      <div className="form-group row">
        <div className="col-md-10">
          <Btn metodo={metodo} />
        </div>
      </div>
    </Form>
  );
}
