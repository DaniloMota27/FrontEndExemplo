import {selectForm} from './checkform'
import React, {Component} from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'


class FormComponent extends Component {
    
    render()
    {
    const formulario = this.props.formulario
    const action = this.props.action
    const readOnly = this.props.readOnly
    const dataForm = this.props.tab.data
    
    
    
    return(
        <div className="form-group">
             {selectForm(formulario, action, dataForm)} 
             {this.props.children}  
          
        </div>
        )
    }
}


const mapStateToProps = state => ({tab: state.tab})
export default connect(mapStateToProps)(FormComponent)







