
import React, {Component} from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import {innit} from '../../../redux/actions/managerurlsActions'
import {update} from '../../../redux/actions/managergmudActions'

class Btn extends Component {
    render(){
   
    return(
             <div>
                 
                 {this.props.metodo == 'delete' ? <button  className="btn btn-danger" type="submit">Delete</button> : this.props.metodo == 'post' ? <button className="btn btn-success"  type="submit">Criar</button>: <button className="btn btn-warning"  type="submit">Atualizar</button> }
                
                <button type="button" onClick={this.props.innit} className='btn btn-default'> Cancelar</button>
              </div> 
        )
    }
}


const mapDispatchToProps = dispatch => bindActionCreators({innit, update}, dispatch)

export default connect(null, mapDispatchToProps)(Btn)