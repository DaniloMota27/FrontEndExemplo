import React from "react";
import FormDB from "./formdb";
import FormGMUD from "./formgmud";
import FormServer from "./formserver";
import FormURL from "./formurl";
import FormSigla from "./formsigla";

const selectForm = (formulario, action, dataForm) => {
  switch (formulario) {
    case "gmud":
      if (action == "create") {
        return <FormGMUD method="post" />;
      } else if (action == "update") {
        return <FormGMUD method="put" dataForm={dataForm} />;
      } else if (action == "delete") {
        return <FormGMUD method="delete" readOnly={true} dataForm={dataForm} />;
      }

    case "db":
      if (action == "create") {
        return <FormDB method="post" />;
      } else if (action == "update") {
        return <FormDB method="put" dataForm={dataForm} />;
      } else if (action == "delete") {
        return <FormDB method="delete" dataForm={dataForm} readOnly={true} />;
      }
    case "servidor":
      if (action == "create") {
        return <FormServer method="post" />;
      } else if (action == "update") {
        return <FormServer method="put" dataForm={dataForm} />;
      } else if (action == "delete") {
        return (
          <FormServer method="delete" dataForm={dataForm} readOnly={true} />
        );
      }
    case "url":
      if (action == "create") {
        return <FormURL method="post" />;
      } else if (action == "update") {
        return <FormURL method="put" dataForm={dataForm} />;
      } else if (action == "delete") {
        return <FormURL method="delete" dataForm={dataForm} readOnly={true} />;
      }
    case "siglas":
      if (action == "create") {
        return <FormSigla method="post" />;
      } else if (action == "update") {
        return <FormSigla method="put" dataForm={dataForm} />;
      } else if (action == "delete") {
        return (
          <FormSigla method="delete" dataForm={dataForm} readOnly={true} />
        );
      }
    default:
      return {};
  }
};

export { selectForm };
