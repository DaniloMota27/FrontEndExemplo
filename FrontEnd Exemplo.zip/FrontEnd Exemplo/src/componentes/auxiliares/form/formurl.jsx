import React, { useEffect, useState, useRef } from "react";
import { useDispatch } from "react-redux";
import axios from "axios";
import { Form } from "@unform/web";
import { Scope } from "@unform/core";
import Input from "./input";
import Label from "./label";
import * as Yup from "yup";
import Btn from "./btn";
import { toastr } from "react-redux-toastr";
import { innit } from "../../../redux/actions/managerurlsActions";
import Select from "./select";

export default function FormURL(props) {
  const formRef = useRef(null);
  const metodo = props.method;
  const initialData = props.dataForm;
  
  const dispatch = useDispatch();
  const readOnly = props.readOnly;
  const options = [
    { label: "Excluído", value: "Removido" },
    { label: "Não Excluído", value: "Online" },
    
  ];

  async function submit(data, { reset }) {
      
    try {
      const schema = Yup.object().shape({
        endSite: Yup.string().required("Informe um site do IIS!"),
        regraFw: Yup.string().required("Informe se existe regra de firewall!"),
        vip: Yup.string().required("Informe se existe um vip!"),
        cer: Yup.string().required("Informe se existe um certificado!"),
        servidor: Yup.object().shape({
            hostname: Yup.string().required("Informe um hostname!"),
            disco: Yup.string().required("Informe o tamnho do Disco!"),
            memoria: Yup.string().required("Informe a quantidade de memoria!"),
            vcpu: Yup.string().required("Informe a quantidade de Vcpu!"),
        }),
        sigla: Yup.object().shape({
            nome: Yup.string().required("Informe a Sigla!"),
            responsavel: Yup.string().required("Informe o responsável!"),
            diretoria: Yup.string().required("Informe a diretoria!"),
        }),
        banco: Yup.object().shape({
            nome: Yup.string().required("Informe o nome!"),
            tamanho: Yup.string().required("Informe o tamanho!"),
        })
        
        
      });
      await schema.validate(data, {
        abortEarly: false,
      });
      formRef.current.setErrors({});
      const baseUrl = "http://127.0.0.1:8000/api/v2";
      const id = data.id ? data.id : "";
      const url =
        metodo == "post" ? `${baseUrl}/urls/` : `${baseUrl}/urls/${id}/`;
      await axios[metodo](`${url}`, data)
        .then((resp) => {
          const success = toastr.success(
            "Sucesso",
            "Operação realizada com sucesso"
          );
        })
        .then((e) => dispatch(innit()))
        .catch((e) => {
          e.response.data.errors.forEach((error) =>
            toastr.error("Erro", error)
          );
        });
      if ((motodo = "post")) {
        reset();
      }
    } catch (err) {
      if (err instanceof Yup.ValidationError) {
          
        const errorMessages = {};
        err.inner.forEach((error) => {
          errorMessages[error.path] = error.message;
        });
        formRef.current.setErrors(errorMessages);
      }
    }
  }

  return (
    <Form ref={formRef} initialData={initialData} onSubmit={submit}>
      <fieldset>
        <legend>Dados da URL:</legend>
        <div className="form-row">
          <div className="form-group col-md-6">
             <Input type='hidden' name='id' /> 
            <Label label="Nome do Site:" />
            <Input readOnly={readOnly} name="endSite" type="text" />
          </div>
          <div className="form-group col-md-2">
            <Label label="Firewall:" />
            <Select readOnly={readOnly} name="regraFw" options={options} />
            
          </div>
          <div className="form-group col-md-2">
            <Label label="SSB:" />
            <Select readOnly={readOnly} name="vip" options={options} />
            
          </div>
          <div className="form-group col-md-2">
            <Label label="Certificado:" />
            <Select readOnly={readOnly} name="cer" options={options} />
            
          </div>
        </div>
      </fieldset>
      <fieldset>
        <legend>Dados do Servidor:</legend>
        <Scope path="servidor">
          <div className="form-row">
            <div className="form-group col-md-4">
              <Label label="Hostname:" />
              <Input readOnly={readOnly} name="hostname" type="text" />
            </div>
            <div className="form-group col-md-2">
              <Label label="Tamanho do disco" />
              <Input readOnly={readOnly} name="disco" type="number" />
            </div>
            <div className="form-group col-md-2">
              <Label label="Memoria" />
              <Input readOnly={readOnly} name="memoria" type="number" />
            </div>
            <div className="form-group col-md-2">
              <Label label="VCPU" />
              <Input readOnly={readOnly} name="vcpu" type="number" />
            </div>

            <div className="form-group col-md-2">
              <Label label="Excluido" />
              <Select readOnly={readOnly} name="excluido" options={options} />
            </div>
            
          </div>
        </Scope>
      </fieldset>

      <div className="form-row ">
        <fieldset className="col-md-6">
          <legend>Sigla:</legend>
          <Scope path="sigla">
            <div className="form-group col-md-4">
              <Label label="Nome da Sigla:" />
              <Input readOnly={readOnly} name="nome" type="text" />
            </div>
            <div className="form-group col-md-4">
              <Label label="Responsável:" />
              <Input readOnly={readOnly} name="responsavel" type="text" />
            </div>
            <div className="form-group col-md-4">
              <Label label="Diretoria:" />
              <Input readOnly={readOnly} name="diretoria" type="text" />
            </div>
          </Scope>
        </fieldset>
        <fieldset className="col-md-6">
          <legend>Banco de Dados:</legend>
          <Scope path="banco">
           
            <div className="form-group col-md-4">
              <Label label="Nome do Banco:" />
              <Input readOnly={readOnly} name="nome" type="text" />
            </div>
            <div className="form-group col-md-4">
              <Label label="Tamanho do Banco" />
              <Input readOnly={readOnly} name="tamanho" type="number" />
            </div>
            <div className="form-group col-md-4">
              <Label label="Excluido" />
              <Select readOnly={readOnly} name="excluido" options={options} />
            </div>

            

          </Scope>
        </fieldset>
      </div>

      <div className="form-group row">
        <div className="col-md-10">
          <Btn metodo={metodo} />
        </div>
      </div>
    </Form>
  );
}
