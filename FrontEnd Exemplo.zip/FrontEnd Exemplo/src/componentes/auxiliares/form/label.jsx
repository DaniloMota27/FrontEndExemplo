import React from 'react'

export default (props) => {
    return(
        <label for={props.for}>{props.label}</label>
    )
}