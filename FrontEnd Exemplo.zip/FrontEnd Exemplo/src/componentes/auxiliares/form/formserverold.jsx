import React, { useRef } from 'react'
import { Form } from '@unform/web'
import Input from './input'
import Label from './label'
import Text from './text'
import * as Yup from 'yup'
import Btn from './btn'


export default function FormServer(props) {
    const formRef = useRef(null);
    const initialData = props.dataForm 
    const metodo = props.method
    const readOnly = props.readOnly
    
    async function handleSubmit(data, { reset }) {
        try {
            const schema = Yup.object().shape({
                hostname: Yup.string().required('Informe um hostname válido!'),
                disco: Yup.string().required('Informe a quantidade de disco!'),
                memoria: Yup.string().required('Informe a quantidade de memória!'),
                url: Yup.string().required('Informe uma url válida!')
            })
            await schema.validate(data, {
                abortEarly: false,
            })
            formRef.current.setErrors({})
            reset();



        }
        catch (err) {
            if (err instanceof Yup.ValidationError) {
                const errorMessages = {};
                err.inner.forEach(error => {
                    errorMessages[error.path] = error.message
                })
                formRef.current.setErrors(errorMessages)

            }
        }

    }
    return (
        <Form ref={formRef} initialData={initialData} onSubmit={handleSubmit}>
            <div className="form-row">
                    <div className="form-group col-md-6">
                        <Label for="hostnameservidor" label="Hostname:" />
                        <Input readOnly={readOnly} name='hostname' type='text' />
                    </div>
                    <div className="form-group col-md-6">
                        <Label for="urlservidor" label="Digite a Url do Servidor:" />
                        <Input readOnly={readOnly} name='url' type='text' />   
                    </div>
            </div>
            <div className="form-row">
                    <div className="form-group col-md-6">
                            <Label for="memoriaservidor" label="Quantidade de Memoria:" />
                            <Input readOnly={readOnly} name='memoria' type='number' />
                    </div>
                    <div className="form-group col-md-6">
                            <Label for="discoservidor" label="Tamanho de disco:" />
                            <Input readOnly={readOnly} name='disco' type='number' />
                    </div>
            </div>

            <div className="form-group row">
                <div className="col-md-10">
                    <Btn metodo={metodo}/>
                </div>
            </div>
            
            
           
           

        </Form>

    )
}



