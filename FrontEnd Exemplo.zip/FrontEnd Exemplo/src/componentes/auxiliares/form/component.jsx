import React from 'react'
import { Form } from '@unform/web'
import Input from './input'
import Label from './label'


export default function FormGMUD(props){
    return (      
        <Form ref={formRef} initialData={initialData} onSubmit={submit}>
               <div className="form-row">
                    <div className="form-group col-md-4">
                            <Label for="numerodagmud" label="Digite o número da GMUD" />
                            <Input name='numero' readOnly={readOnly} type='text' />
                    </div>
                    <div className="form-group col-md-4">
                            <Label for="complementogmud" label="Descrição:" />
                            <Input name='complemento' readOnly={readOnly} type='text' />
                    </div>
                    <div className="form-group col-md-4">
                            <Label for="datagmud" label="Data de execução:" />
                            <Input name='data' readOnly={readOnly} type='datetime' />
                    </div>
                </div>

            <div className="form-group row">
                <div className="col-md-10">
                    <Btn metodo={metodo}/>
                </div>
            </div>           
        </Form>
    )
}


async function submit(data, { reset }) {
    try {
        const schema = Yup.object().shape({
            numero: Yup.string().required('Informe o número da gmud'),
            complemento: Yup.string().required('Informe uma descrição'),
            data: Yup.string().required('Informe uma data válida')
        })
        await schema.validate(data, {
            abortEarly: false,
        })
        formRef.current.setErrors({})

        useEffect(() => {
            const id = data.id ? data.id : ''
            axios.post(`http://127.0.0.1:8000/api/v2/gmuds/${id}`, data)
                            .then(resp => {
                            toastr.success('Sucesso', 'Operação realizada com sucesso')
                            })
                            .catch(e => { e.response.data.errors.forEach(error => toastr.error('Erro', error))})}, data);   
            innit()                     
            reset();
        

    }
    catch (err) {
        if (err instanceof Yup.ValidationError) {
            const errorMessages = {};
            err.inner.forEach(error => {
                errorMessages[error.path] = error.message
            })
            formRef.current.setErrors(errorMessages)
        }
    }