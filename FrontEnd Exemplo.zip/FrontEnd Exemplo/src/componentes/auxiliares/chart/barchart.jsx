import React, {Component} from 'react'
import Chart from 'react-apexcharts'
import Grid from '../layout/grid'

var options = {
    series: [{
    data: [400, 430, 448, 470, 540, 580, 690, 1100, 1200, 1380, 1200, 1380]
  }],
    chart: {
    type: 'bar',
    height: 350
  },
  plotOptions: {
    bar: {
      horizontal: true,
    }
  },
  dataLabels: {
    enabled: false
  },
  xaxis: {
    categories: ['Jan-21', 'Fev-21', 'Mar-21', 'Abr-21', 'Mai-21', 'Jun-21', 'Jul-21',
      'Ago-21', 'Set-21', 'Out-21' , 'Nov-21' , 'Dez-21'
    ],
  }
  };

  
  class ChartBar extends Component {
    constructor(props) {
        super(props);
        
        this.state = {
            options
          
          };
        }  
      
    
    render(){
        return(
            <Grid cols={this.props.cols}>
                <Chart options={this.state.options} series={this.state.options.series} height={350} />
        </Grid>
        )
    }
  }


  
  
  export default ChartBar 
  