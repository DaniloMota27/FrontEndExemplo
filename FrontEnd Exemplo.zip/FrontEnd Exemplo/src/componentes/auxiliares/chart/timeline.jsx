import React, {Component} from 'react'
import Chart from 'react-apexcharts'
import Grid from '../layout/grid'

class Timeline extends Component {
    constructor(props) {
      super(props);
  
      this.state = {
        series: [
            {
              data: [
                {
                  x: 'GMUD-1',
                  y: [
                    new Date('2019-03-02').getTime(),
                    new Date('2019-03-04').getTime()
                  ]
                },
                {
                  x: 'GMUD-2',
                  y: [
                    new Date('2019-03-04').getTime(),
                    new Date('2019-03-08').getTime()
                  ]
                },
                {
                  x: 'GMUD-3',
                  y: [
                    new Date('2019-03-08').getTime(),
                    new Date('2019-03-12').getTime()
                  ]
                },
                {
                  x: 'GMUD-4',
                  y: [
                    new Date('2019-03-12').getTime(),
                    new Date('2019-03-18').getTime()
                  ]
                }
              ]
            }
          ],
          options: {
            chart: {
              height: 350,
              type: 'rangeBar'
            },
            plotOptions: {
              bar: {
                horizontal: true
              }
            },
            xaxis: {
              type: 'datetime'
            }
          },
        
        
        };
      }  
    
    
    render() {
      return (
        <Grid cols={this.props.cols}>
        <Chart options={this.state.options} series={this.state.series} type="rangeBar" height={350} />
        </Grid>
      )
    }
  }

  export default Timeline