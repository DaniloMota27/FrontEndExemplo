import React from 'react'

const TimelineItem = (props) => {
    
    const {date, text, link, category, tag } = props.data.data
    
    return(
    <div className="timeline-item">
        <div className="timeline-item-content">
            <span className="tag" style={`background: ${category.color}`}>
                {tag}
            </span>
            <time>{date}</time>
            <p>{text}</p>
            {link && (
                <a
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    {link.text}
                </a>
            )}
            <span className="circle" />
        </div>
    </div>
    )
            };

export default TimelineItem