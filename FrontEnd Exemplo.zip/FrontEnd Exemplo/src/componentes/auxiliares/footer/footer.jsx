import React from 'react'

export default props => (
    <footer className="main-footer">
        <strong>
            Dúvidas:
        </strong>
        <span> danilo.mota-raymundo@itau-unibanco.com.br</span>
    </footer>
)