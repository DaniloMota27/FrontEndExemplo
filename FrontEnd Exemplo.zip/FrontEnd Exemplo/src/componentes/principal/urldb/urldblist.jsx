import React, {Component} from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import {getList} from '../../../redux/actions/urlsdbActions'
import {showUpdate, showDelete} from '../../../redux/actions/urlsdbActions'


class ManagerDBList extends Component {
    componentWillMount(){
        this.props.getList()
    }
    renderRows(){
        
        const list = this.props.list || []
        
        return list.map(db =>(
            <tr key={db.id}>
                
                <td>{db.nome}</td>
                <td>{db.tamanho}</td>
                <td>{db.excluido ? 'Excluído' : 'Não Excluído'}</td>
                
                
                <td>
                <button className="btn btn-warning" 
                    onClick={() => this.props.showUpdate(db)}
                    ><i className='fa fa-pencil'></i>
                    </button>
                    <button className="btn btn-danger"
                    onClick={() => this.props.showDelete(db)}
                    ><i className='fa fa-trash-o'></i>
                    </button>

                </td>
            </tr>
        ))
    }
    render(){
        return(
            <table className='table'>
                
            <thead>
                <tr>
                    <th>Nome do Banco</th>
                    <th>Tamanho do Banco</th>
                    <th>Excluído</th>
                    
                    
                    <th className="table-actions">Ações</th>
                </tr>
            </thead>
            <tbody>
                {this.renderRows()}
            </tbody>
        
        </table>  
        )
    }
}

const mapStateToProps = state => ({
    list: state.admbancos.list
})


const mapDispacthToProps = (dispatch) => bindActionCreators({getList, showDelete, showUpdate}, dispatch)


export default connect(mapStateToProps,mapDispacthToProps)(ManagerDBList)