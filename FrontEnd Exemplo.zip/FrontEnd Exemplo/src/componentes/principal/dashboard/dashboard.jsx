import React, { Component } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { getSummary } from "../../../redux/actions/dashBoardAction";
import ContentHeader from "../../auxiliares/tab/tabsheaders";
import Content from "../../auxiliares/body/content";
import ValueBox from "../../auxiliares/widget/valueBox";
import Row from "../../auxiliares/layout/row";
import Timeline from "../../auxiliares/chart/timeline";
import BarChart from "../../auxiliares/chart/barchart";

class Dashboard extends Component {
  componentWillMount() {
    this.props.getSummary();
  }

  render() {
    const { vcpu, disco, memoria } = this.props.infoservers;

    return (
      <div>
        <ContentHeader title="Dashboard" small="Versão 1.0" />
        <Content>
          <Row>
            <ValueBox
              cols="12 4"
              color="blue"
              icon="internet-explorer"
              value={`${vcpu} VCPU`}
              text="Saving - VCPU"
            />
            <ValueBox
              cols="12 4"
              color="red"
              icon="server"
              value={`${memoria} GB`}
              text="Saving - Memoria"
            />
            <ValueBox
              cols="12 4"
              color="green"
              icon="group"
              value={`${disco} GB`}
              text="Saving - Disco"
            />
          </Row>
          <fieldset>
            <legend>Overview Status Report "go-aHead"</legend>
            <Row>
              <div>
                <Timeline cols="12 6" />
                <BarChart cols="12 6" />
              </div>
            </Row>
          </fieldset>
        </Content>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({ infoservers: state.dashboard.data });
const mapDispatchToProps = (dispatch) =>
  bindActionCreators({ getSummary }, dispatch);
export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);
