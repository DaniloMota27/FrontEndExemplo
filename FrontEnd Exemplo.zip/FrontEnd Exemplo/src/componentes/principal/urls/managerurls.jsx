import React, {Component} from 'react'
import ContentHeader from '../../auxiliares/header/contentheader'
import Content from '../../auxiliares/body/content'
import ManagerURLSList from './managerurlslist'
import Tabs from '../../auxiliares/tab/tabs'
import TabHeader from '../../auxiliares/tab/tabheader'
import TabsHeaders from '../../auxiliares/tab/tabsheaders'
import TabsContent from '../../auxiliares/tab/tabscontent'
import TabContent from '../../auxiliares/tab/tabcontent'
import FormComponent from '../../auxiliares/form/form'
import {innit} from '../../../redux/actions/managerurlsActions'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'


 class ManagerUrls extends Component {
    componentWillMount(){

        this.props.innit()
       
    }
    render(){
        return(
            <div>
                <ContentHeader title="URLS Manager" small='Cadastro' />
                <Content>
                <Tabs>
                    <TabsHeaders>
                        <TabHeader label=' Listar' icon='bars' target='tabList'></TabHeader>
                        <TabHeader label=' Incluir' icon='plus' target='tabIncluir'></TabHeader>
                        <TabHeader label=' Alterar' icon='pencil' target='tabUpdate'></TabHeader>
                        <TabHeader label=' Excluir' icon='trash-o' target='tabDelete'></TabHeader>
                    </TabsHeaders>
                    <TabsContent>
                            <TabContent id='tabList'><ManagerURLSList /></TabContent>
                            <TabContent id='tabIncluir'><FormComponent formulario="url" action='create'/></TabContent>
                            <TabContent id='tabUpdate'><FormComponent formulario='url' action='update' /></TabContent>
                            <TabContent id='tabDelete'><FormComponent formulario='url' action='delete' /></TabContent>
                        </TabsContent>
                </Tabs>
            </Content>

                
            </div>
        )
    }
}


const mapDispacthToProps = dispatch => bindActionCreators({innit}, dispatch)

export default connect(null, mapDispacthToProps)(ManagerUrls)