import React, { Component } from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { getList } from "../../../redux/actions/managerurlsActions";
import {
  showUpdate,
  showDelete,
} from "../../../redux/actions/managerurlsActions";

class ManagerURLSList extends Component {
  componentWillMount() {
    this.props.getList();
  }
  renderRows() {
    const list = this.props.list || [];
    
    return list.map((urls) => (
      <tr key={urls.id}>
        <td>{urls.endSite}</td>
        <td>{urls.regraFw ? 'Desativado' : 'NotFound'}</td>
        <td>{urls.vip ? 'Desativado' : 'NotFound'}</td>
        <td>{urls.cer ? 'Desativado' : 'NotFound'}</td>
        <td>{urls.sigla.nome}</td>
        <td>{urls.sigla.diretoria}</td>
        <td>{urls.servidor.hostname}</td>
        <td>{urls.banco.nome}</td>

        
        <td>
          <button
            className="btn btn-warning"
            onClick={() => this.props.showUpdate(urls)}
          >
            <i className="fa fa-pencil"></i>
          </button>
          <button
            className="btn btn-danger"
            onClick={() => this.props.showDelete(urls)}
          >
            <i className="fa fa-trash-o"></i>
          </button>
        </td>
      </tr>
    ));
  }
  render() {
    return (
      <table className="table">
        <thead>
          <tr>
            <th>Site</th>
            <th>Regra de Firewall</th>
            <th>Vip</th>
            <th>Certificado</th>
            <th>Sigla</th>
            <th>Diretoria</th>
            <th>Servidor</th>
            <th>Banco de Dados</th>
            <th className="table-actions">Ações</th>
          </tr>
        </thead>
        <tbody>{this.renderRows()}</tbody>
      </table>
    );
  }
}

const mapStateToProps = (state) => ({
  list: state.admurls.list,
});

const mapDispacthToProps = (dispatch) =>
  bindActionCreators({ getList, showDelete, showUpdate }, dispatch);

export default connect(mapStateToProps, mapDispacthToProps)(ManagerURLSList);
