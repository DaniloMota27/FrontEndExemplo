import React, {Component} from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import {getList} from '../../../redux/actions/managersiglasActions'
import {showUpdate, showDelete} from '../../../redux/actions/managersiglasActions'





class ManagerSiglaList extends Component {
    componentWillMount(){
        this.props.getList()
    }
    renderRows() {
        const list = this.props.list || []
        //function ()
        return list.map(sigla => (
            
            <tr key={sigla.id}>
                <td>{sigla.nome}</td>
                <td>{sigla.responsavel}</td>
                <td>{sigla.diretoria}</td>
                <td>
                <button className="btn btn-warning" 
                    onClick={() => this.props.showUpdate(sigla)}
                    ><i className='fa fa-pencil'></i>
                    </button>
                    <button className="btn btn-danger"
                    onClick={() => this.props.showDelete(sigla)}
                    ><i className='fa fa-trash-o'></i>
                    </button>

                </td>
            </tr>
        ))
    }
    render()
    {
        return(
            <table className='table'>
                
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Responsável</th>
                        <th>Diretoria</th>
                        <th className="table-actions">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    {this.renderRows()}
                </tbody>
            
            </table>    
        )
    }
}

const mapStateToProps = state => ({
    list: state.admsiglas.list
    
    
})
const mapDispatchToProps = dispatch => bindActionCreators({getList, showDelete, showUpdate}, dispatch)

export default connect(mapStateToProps, mapDispatchToProps)(ManagerSiglaList)