import React, {Component} from 'react'
import ContentHeader from '../../auxiliares/header/contentheader'
import Content from '../../auxiliares/body/content'
import ManagerGMUDSList from './managergmudlist'
import Tabs from '../../auxiliares/tab/tabs'
import TabHeader from '../../auxiliares/tab/tabheader'
import TabsHeaders from '../../auxiliares/tab/tabsheaders'
import TabsContent from '../../auxiliares/tab/tabscontent'
import TabContent from '../../auxiliares/tab/tabcontent'
import FormComponent from '../../auxiliares/form/form'
import {innit} from '../../../redux/actions/managergmudActions'
import {getList} from '../../../redux/actions/managergmudActions'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'


class ManagerGMUD extends Component {
    componentWillMount(){
        this.props.innit()
        this.props.getList()
    }
    
    render() {
       

        
        return (
            <div>
                <ContentHeader title="GMUDS Manager" small='Cadastro' />
                <Content>
                <Tabs>
                    <TabsHeaders>
                        <TabHeader label=' Listar' icon='bars' target='tabList'></TabHeader>
                        <TabHeader label=' Incluir' icon='plus' target='tabIncluir'></TabHeader>
                        <TabHeader label=' Alterar' icon='pencil' target='tabUpdate'></TabHeader>
                        <TabHeader label=' Excluir' icon='trash-o' target='tabDelete'></TabHeader>
                    </TabsHeaders>
                    <TabsContent>
                            <TabContent id='tabList'><ManagerGMUDSList /></TabContent>
                            <TabContent id='tabIncluir'><FormComponent formulario='gmud' action='create'/></TabContent>
                            <TabContent id='tabUpdate'><FormComponent formulario='gmud' action='update'/></TabContent>
                            <TabContent id='tabDelete'><FormComponent formulario='gmud' action='delete' /></TabContent>
                        </TabsContent>
                </Tabs>
            </Content>
            </div>
        )
    }


}

const mapDispacthToProps = dispatch => bindActionCreators({getList,innit}, dispatch)

export default connect(null, mapDispacthToProps)(ManagerGMUD)