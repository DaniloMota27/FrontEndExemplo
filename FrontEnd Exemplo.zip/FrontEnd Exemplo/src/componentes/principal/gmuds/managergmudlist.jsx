import React, {Component} from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import {getList} from '../../../redux/actions/managergmudActions'
import {showUpdate, showDelete} from '../../../redux/actions/managergmudActions'





class ManagerGMUDList extends Component {
    componentWillMount(){
        this.props.getList()
    }
    renderRows() {
        const list = this.props.list || []
        //function ()
        return list.map(gmud => (
            
            <tr key={gmud.id}>
                <td>{gmud.numero}</td>
                <td>{gmud.complemento}</td>
                <td>{gmud.start}</td>
                <td>{gmud.end}</td>
                <td>
                <button className="btn btn-warning" 
                    onClick={() => this.props.showUpdate(gmud)}
                    ><i className='fa fa-pencil'></i>
                    </button>
                    <button className="btn btn-danger"
                    onClick={() => this.props.showDelete(gmud)}
                    ><i className='fa fa-trash-o'></i>
                    </button>

                </td>
            </tr>
        ))
    }
    render()
    {
        return(
            <table className='table'>
                
                <thead>
                    <tr>
                        <th>Numero</th>
                        <th>Descrição</th>
                        <th>Incio</th>
                        <th>Termino</th>
                        <th className="table-actions">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    {this.renderRows()}
                </tbody>
            
            </table>    
        )
    }
}

const mapStateToProps = state => ({
    list: state.admgmuds.list
    
    
})
const mapDispatchToProps = dispatch => bindActionCreators({getList, showDelete, showUpdate}, dispatch)

export default connect(mapStateToProps, mapDispatchToProps)(ManagerGMUDList)