import React, {Component} from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import {getList} from '../../../redux/actions/servidoresActions'
import {showUpdate, showDelete} from '../../../redux/actions/servidoresActions'


class ManagerServerList extends Component {
    componentWillMount(){
        this.props.getList()
        
        
    }
    renderRows(){
        
        const list = this.props.list || []
        return list.map(servidor => (
              <tr key={servidor.id}>
                    
                    <td>{servidor.hostname}</td>
                    <td>{servidor.disco}</td>
                    <td>{servidor.memoria}</td>
                    <td>{servidor.vcpu}</td>
                    <td>{servidor.excluido ? 'Excluído' : 'Não Excluído'}</td>
                    <td>
                    <button className="btn btn-warning" 
                    onClick={() => this.props.showUpdate(servidor)}
                    ><i className='fa fa-pencil'></i>
                    </button>
                    <button className="btn btn-danger"
                    onClick={() => this.props.showDelete(servidor)}
                    ><i className='fa fa-trash-o'></i>
                    </button>

                </td>
            </tr>
        ))
    
    }
    render(){
        return (
            <table className='table'>
                
            <thead>
      
                <tr>
                    
                    <th>Hostname</th>
                    <th>Disco</th>
                    <th>Memoria</th>
                    <th>VCPU</th>
                    <th>Excluído</th>
                    <th className="table-actions">Ações</th>
                </tr>
            </thead>
            <tbody>
                {this.renderRows()}
            </tbody>
        
        </table>    
        )    
    
    }
}

const mapStateToProps = (state) => ({
    list: state.admservidores.list
})

const mapDispatchToProps = (dispatch) => bindActionCreators({getList, showDelete, showUpdate}, dispatch)

export default connect(mapStateToProps, mapDispatchToProps)(ManagerServerList)