import React from 'react'
import ReactDom from 'react-dom'
import App from './main/app'
import reducers from './redux/reducers/reducers'
import { applyMiddleware, createStore} from 'redux'
import {Provider} from 'react-redux'
import promise from 'redux-promise'
import multi from 'redux-multi'
import thunk from 'redux-thunk'

const store = applyMiddleware(thunk, multi, promise)(createStore)(reducers)



const app = document.getElementById('app')

ReactDom.render(<Provider store={store}><App /></Provider>, app)