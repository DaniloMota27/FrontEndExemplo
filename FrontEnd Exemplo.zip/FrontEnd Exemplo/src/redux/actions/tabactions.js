
export function selectTab (tabId) {

    return{
        type: 'TAB_SELECTED',
        payload: tabId
    }
}

export function showTabs(...tabIds){
    const tabToShow = {}
    tabIds.forEach(element => tabToShow[element] = true);
    return{
        type: 'TAB_SHOWED',
        payload: tabToShow
    }
}

export function LoadForm(data){
    return{
        type: 'LOAD_FORM',
        payload: data
    }

}