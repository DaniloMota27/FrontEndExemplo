import axios from 'axios'
import {showTabs, selectTab, LoadForm} from './tabactions'

const base_url = 'http://127.0.0.1:8000/api/v2'

export const getList = () => {
    const request = axios.get(`${base_url}/gmuds/`)
    
    return{
        type: 'Get_List_Manager_GMUDS',
        payload: request
    }
}


export function create(values) {
    return{}
 
    
}

export function update(values) {
    return {}
}

export function remove(values) {
    return {}
}


export function showUpdate(element) {
    
    return [ 
        showTabs('tabUpdate'),
        selectTab('tabUpdate'),
        LoadForm(element)
        
    ]
}

export function showDelete(element) {
    return [ 
        showTabs('tabDelete'),
        selectTab('tabDelete'),
        LoadForm(element)
        
    ]
}

export function innit() {
    return [
        showTabs('tabList', 'tabIncluir'),
        selectTab('tabList'),
        getList(),
        
    ]
}

