import axios from 'axios'


const BASE_URL = 'http://127.0.0.1:8000/api/v2/servidores/'

const getSummary = () => {
    
    const request =axios.get(`${BASE_URL}`)
    
   
    return {
        type: 'Servidores_Summary_fetched',
        payload: request
    }
}

export {getSummary}