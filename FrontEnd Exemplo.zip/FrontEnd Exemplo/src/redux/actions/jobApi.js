import axios from "axios";
import { toastr } from "react-redux-toastr";
import { innit } from "./managergmudActions";

function apiJob(rota, metodo, data) {
  const baseUrl = "http://127.0.0.1:8000/api/v2";
  const id = data.id ? data.id : "";
  const url =
    metodo == "post" ? `${baseUrl}/gmuds/` : `${baseUrl}/gmuds/${id}/`;

    axios[metodo](`${url}`, data)
    .then((resp) => {
      const success = toastr.success(
        "Sucesso",
        "Operação realizada com sucesso"
      );
    })
    .catch((e) => {
      e.response.data.errors.forEach((error) => toastr.error("Erro", error));
    });
}

export { apiJob };
