import axios from 'axios'
import {showTabs, selectTab, LoadForm} from './tabactions'
const baseUrl = 'http://127.0.0.1:8000/api/v2'

export function getList(){
    const request = axios.get('http://127.0.0.1:8000/api/v2/servidores/')
    
    return {
        type: 'Get_List_Manager_Servidores',
        payload: request
    }

}


export function showUpdate(element) {
    return [ 
        showTabs('tabUpdate'),
        selectTab('tabUpdate'),
        LoadForm(element)
    ]
}

export function showDelete(element) {
    return [ 
        showTabs('tabDelete'),
        selectTab('tabDelete'),    
        LoadForm(element)
        
    ]
}

export function innit() {
    return [
        showTabs('tabList', 'tabIncluir'),
        selectTab('tabList'),
        getList(),
        
    ]
}


