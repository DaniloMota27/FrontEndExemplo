const innit_state = {select: '', visible: {}}

export default (state = innit_state, action) => {
    switch(action.type){
        case 'TAB_SELECTED':
        
           return {...state, selected: action.payload }
        case 'TAB_SHOWED':
            return {...state, visible: action.payload}
        
        case 'LOAD_FORM':
                return {...state, data: action.payload}
            
        default:
            return state
    }
}
