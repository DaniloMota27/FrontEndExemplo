import {combineReducers} from 'redux'
import {reducer as formReducer} from 'redux-form'
import DashboardReducer from './dashboardReducer'
import ManagerURLSReducer from './managerurlsReducer'
import ManagerGMUDReducer from './managergmudReducer'
import ManagerServerReducer from './servidoresReducer'
import ManagerDBReducer from './urlsdbReducer'
import TabReducer from './tabsReducer'
import SiglasReducer from './managersiglasReducer'

import {reducer as toastrReducer} from 'react-redux-toastr'

const rootReducer = combineReducers({   
    dashboard: DashboardReducer,
    tab: TabReducer,
    admurls: ManagerURLSReducer,
    admgmuds: ManagerGMUDReducer,
    admservidores: ManagerServerReducer,
    admbancos: ManagerDBReducer,
    admsiglas: SiglasReducer,
    toastr: toastrReducer,
    form: formReducer


})
export default rootReducer 