const initValues =  {data: {
                              memoria: 0,
                              vcpu: 0,
                              disco: 0
                            }}


export default (state = initValues, action) => {
    
    switch(action.type){
        case 'Servidores_Summary_fetched':
            const values = action.payload.data.results
            
            const objDiscoServer = values.reduce ((disco, o) => disco + parseInt(o.disco), 0);
            const objMemoriaServer = values.reduce ((memoria, o) => memoria + parseInt(o.memoria), 0);
            const objVcpuServer = values.reduce ((vcpu, o) => vcpu + parseInt(o.vcpu), 0);
            const data = {                
                    memoria: parseInt(objMemoriaServer),
                    vcpu: parseInt(objVcpuServer),
                    disco: parseInt(objDiscoServer)
            }

            return {...state, data: data}
            default:{
  
                return state
            }
        }
    
 
}