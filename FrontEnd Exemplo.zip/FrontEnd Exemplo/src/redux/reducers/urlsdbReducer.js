export default (state = {}, action) => {
    switch(action.type){
        
        case 'Get_List_Manager_DB':
            const values = action.payload.data.results
            
            return { ...state,
                list: values
            }
        default:
            return state
    }
}